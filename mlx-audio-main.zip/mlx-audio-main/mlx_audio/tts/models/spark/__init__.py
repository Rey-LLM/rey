from .spark import Model, ModelConfig
