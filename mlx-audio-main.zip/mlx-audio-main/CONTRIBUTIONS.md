# Contributions

This file acknowledges the original authors and contributors of models ported to mlx-audio.

## MossFormer2 SE (Speech Enhancement)

- **Original**: [ClearerVoice-Studio](https://github.com/modelscope/ClearerVoice-Studio)
- **Copyright**: Speech Lab, Alibaba Group
- **License**: Apache License 2.0
- **MLX Port**: Dmitry Starkov ([@starkdmi](https://github.com/starkdmi))
